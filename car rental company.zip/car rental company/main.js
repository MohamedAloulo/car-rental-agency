const btn = document.getElementById("btn");
const navLinks = document.getElementById("navbarNav")
btn.addEventListener('click', () => {
    navLinks.classList.toggle('true')
    if(navLinks.style.display=="none"){
        navLinks.style.display="flex";
    }else{
        navLinks.style.display="none";
    }
});
window.onload = ()=>{
     navLinks.style.display="none"
}

const sections = document.querySelectorAll('section');
const NavLinks = document.querySelectorAll('.navbar-nav .nav-link');

        const observerOptions = {
            root: null,
            threshold: 0.5 
        };

        function handleIntersection(entries) {
            entries.forEach(entry => {
                const link = document.querySelector(`a[href="#${entry.target.id}"]`);
                if (entry.isIntersecting) {
                    link.classList.add('active');
                } else {
                    link.classList.remove('active');
                }
            });
        }

        const observer = new IntersectionObserver(handleIntersection, observerOptions);

        sections.forEach(section => {
            observer.observe(section);
        });